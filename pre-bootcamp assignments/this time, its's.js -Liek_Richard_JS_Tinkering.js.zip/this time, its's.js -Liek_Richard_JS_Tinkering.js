function displayifChildIsAbleToRIdeTheRollerCoaster() {
var childheight = 42;
if (childheight > 52);
    console.log("Get on that ride kiddo!");
}
else if{
    console.log("Sorry kiddo. Maybe next year.");
}
