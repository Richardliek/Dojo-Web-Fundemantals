function myBirthYearFunc(){
        console.log("I was born in " + 1980);
    }
//Predict 1: The console.log will define it as Undefined.

function myBirthYearFunc(birthYearInput){
        console.log("I was born in " + birthYearInput);
    }
// Predict 2: The console.log will state "I was born in 1980"

function add(10, 20){       //num1 = 10 and num2 = 20
        console.log("Summing Numbers!");
        console.log("num1 is: " + 10);
        console.log("num2 is: " + 20);
        var sum = 10 + 20;
        console.log(sum);
    }
// Predict 3: The console.og will state the sum of the numbers as 30.